var calc_of_delivery = new Vue({

  el: '#delivery',
  data: {
	address_to_customer:'',
	dlinna_km:0,
  },
  
  methods:{  
	 geo:function(){
	 },
 
})
	
	